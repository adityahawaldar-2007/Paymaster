# Paymaster — Employee Payment Management Mini Project

A beginner-friendly Java mini project with a browser-based dashboard built using HTML, CSS and JavaScript. Backend: Java 17 + Spring Boot REST API. Database: H2 file database.

## Realistic demo features
- Employee directory: add, view, search, edit and delete employees.
- Employee fields: unique employee code, name, email, department, designation, basic salary, allowances, deductions and active status.
- Payroll generation by employee and month, including optional overtime.
- Gross pay, estimated tax, other deductions and net pay calculation.
- Payslip viewer with Print / Save as PDF support.
- Dashboard metrics for total employees, active employees, payroll runs and net payroll total.
- H2 database persists records locally in `./data/paymasterdb`.
- Duplicate employee-code validation and inactive-employee payroll guard.

## Requirements
- JDK 17 or newer
- Maven 3.6+ (or use an IDE with Maven support)
- Web browser

## Run the project
1. Extract `Paymaster.zip`.
2. Open a terminal in the `Paymaster` folder (the folder containing `pom.xml`).
3. Run:
   ```bash
   mvn spring-boot:run
   ```
4. Open `http://localhost:8080`.
5. Stop the server with Ctrl+C.

If using IntelliJ IDEA or Eclipse, import the folder as an existing Maven project and run `PaymasterApplication.java`.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/employees` | List employees |
| GET | `/api/employees/{id}` | Get one employee |
| POST | `/api/employees` | Add employee |
| PUT | `/api/employees/{id}` | Update employee |
| DELETE | `/api/employees/{id}` | Delete employee |
| GET | `/api/payroll` | List payslips |
| GET | `/api/payroll/employee/{id}` | Payroll history for employee |
| POST | `/api/payroll/generate/{employeeId}` | Generate payroll |
| GET | `/api/dashboard` | Dashboard summary |

Example payroll request body:
```json
{
  "payPeriod": "2026-10",
  "overtimePay": 1500
}
```

## Payroll formula used in this educational demo
- Gross pay = basic salary + allowances + overtime pay
- Estimated tax = 5% of gross pay
- Net pay = max(0, gross pay − employee deductions − estimated tax)

**Important:** The 5% tax is only a demo assumption. This project is not production-ready payroll software. It does not implement login/roles, leave management, attendance integration, statutory Indian tax/PF/ESI calculations, bank transfers, audit trails or encrypted secrets. Do not use it to pay real employees without proper security, legal review and payroll validation.

## Project structure
```
Paymaster/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/paymaster/
    │   ├── PaymasterApplication.java
    │   ├── controller/
    │   │   ├── DashboardController.java
    │   │   ├── EmployeeController.java
    │   │   └── PayrollController.java
    │   ├── model/
    │   │   ├── Employee.java
    │   │   └── Payroll.java
    │   └── repository/
    │       ├── EmployeeRepository.java
    │       └── PayrollRepository.java
    └── resources/
        ├── application.properties
        └── static/
            ├── index.html
            ├── styles.css
            └── app.js
```
