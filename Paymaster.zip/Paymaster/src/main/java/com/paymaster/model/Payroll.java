package com.paymaster.model;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
public class Payroll {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private Long employeeId;
    private String employeeName;
    private String employeeCode;
    private String payPeriod;
    private LocalDate generatedOn;
    private double basicSalary, allowances, overtimePay, grossPay, deductions, tax, netPay;
    public Payroll() {}
    public Long getId(){return id;} public void setId(Long v){id=v;}
    public Long getEmployeeId(){return employeeId;} public void setEmployeeId(Long v){employeeId=v;}
    public String getEmployeeName(){return employeeName;} public void setEmployeeName(String v){employeeName=v;}
    public String getEmployeeCode(){return employeeCode;} public void setEmployeeCode(String v){employeeCode=v;}
    public String getPayPeriod(){return payPeriod;} public void setPayPeriod(String v){payPeriod=v;}
    public LocalDate getGeneratedOn(){return generatedOn;} public void setGeneratedOn(LocalDate v){generatedOn=v;}
    public double getBasicSalary(){return basicSalary;} public void setBasicSalary(double v){basicSalary=v;}
    public double getAllowances(){return allowances;} public void setAllowances(double v){allowances=v;}
    public double getOvertimePay(){return overtimePay;} public void setOvertimePay(double v){overtimePay=v;}
    public double getGrossPay(){return grossPay;} public void setGrossPay(double v){grossPay=v;}
    public double getDeductions(){return deductions;} public void setDeductions(double v){deductions=v;}
    public double getTax(){return tax;} public void setTax(double v){tax=v;}
    public double getNetPay(){return netPay;} public void setNetPay(double v){netPay=v;}
}
