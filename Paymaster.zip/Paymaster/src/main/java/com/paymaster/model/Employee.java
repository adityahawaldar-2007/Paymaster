package com.paymaster.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
@Entity
public class Employee {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @NotBlank private String employeeCode;
    @NotBlank private String fullName;
    @NotBlank private String department;
    @NotBlank private String designation;
    @Email @NotBlank private String email;
    @PositiveOrZero private double basicSalary;
    @PositiveOrZero private double allowances;
    @PositiveOrZero private double deductions;
    private boolean active = true;
    public Employee() {}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getEmployeeCode(){return employeeCode;} public void setEmployeeCode(String v){employeeCode=v;}
    public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
    public String getDepartment(){return department;} public void setDepartment(String v){department=v;}
    public String getDesignation(){return designation;} public void setDesignation(String v){designation=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public double getBasicSalary(){return basicSalary;} public void setBasicSalary(double v){basicSalary=v;}
    public double getAllowances(){return allowances;} public void setAllowances(double v){allowances=v;}
    public double getDeductions(){return deductions;} public void setDeductions(double v){deductions=v;}
    public boolean isActive(){return active;} public void setActive(boolean v){active=v;}
}
