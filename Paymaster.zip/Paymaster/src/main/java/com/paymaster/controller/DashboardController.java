package com.paymaster.controller;
import com.paymaster.repository.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/dashboard") @CrossOrigin
public class DashboardController {
 private final EmployeeRepository employees; private final PayrollRepository payrolls;
 public DashboardController(EmployeeRepository e,PayrollRepository p){employees=e;payrolls=p;}
 @GetMapping public Map<String,Object> summary(){
   var active=employees.findAll().stream().filter(x->x.isActive()).count();
   var records=payrolls.findAll();
   double total=records.stream().mapToDouble(x->x.getNetPay()).sum();
   return Map.of("totalEmployees",employees.count(),"activeEmployees",active,"payrollRuns",records.size(),"totalNetPayroll",Math.round(total*100.0)/100.0);
 }
}
