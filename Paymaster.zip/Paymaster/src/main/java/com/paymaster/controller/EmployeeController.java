package com.paymaster.controller;
import com.paymaster.model.Employee;
import com.paymaster.repository.EmployeeRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/employees")
@CrossOrigin
public class EmployeeController {
    private final EmployeeRepository repo;
    public EmployeeController(EmployeeRepository repo){this.repo=repo;}
    @GetMapping public List<Employee> all(){return repo.findAll();}
    @GetMapping("/{id}") public ResponseEntity<Employee> one(@PathVariable Long id){return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
    @PostMapping public ResponseEntity<?> create(@RequestBody Employee e){
        if(repo.findByEmployeeCodeIgnoreCase(e.getEmployeeCode()).isPresent()) return ResponseEntity.badRequest().body(Map.of("message","Employee code already exists."));
        e.setId(null); return ResponseEntity.ok(repo.save(e));
    }
    @PutMapping("/{id}") public ResponseEntity<?> update(@PathVariable Long id,@RequestBody Employee e){
        return repo.findById(id).map(old->{
            Optional<Employee> duplicate=repo.findByEmployeeCodeIgnoreCase(e.getEmployeeCode());
            if(duplicate.isPresent()&&!duplicate.get().getId().equals(id)) return ResponseEntity.badRequest().body(Map.of("message","Employee code already exists."));
            e.setId(id); return ResponseEntity.ok(repo.save(e));
        }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<?> delete(@PathVariable Long id){
        if(!repo.existsById(id)) return ResponseEntity.notFound().build(); repo.deleteById(id); return ResponseEntity.noContent().build();
    }
}
