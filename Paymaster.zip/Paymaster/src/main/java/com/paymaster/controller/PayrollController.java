package com.paymaster.controller;
import com.paymaster.model.*;
import com.paymaster.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;
@RestController @RequestMapping("/api/payroll")
@CrossOrigin
public class PayrollController {
    private final EmployeeRepository employees; private final PayrollRepository payrolls;
    public PayrollController(EmployeeRepository e, PayrollRepository p){employees=e;payrolls=p;}
    @GetMapping public List<Payroll> all(){return payrolls.findAllByOrderByGeneratedOnDesc();}
    @GetMapping("/employee/{id}") public List<Payroll> byEmployee(@PathVariable Long id){return payrolls.findByEmployeeIdOrderByGeneratedOnDesc(id);}
    @PostMapping("/generate/{employeeId}")
    public ResponseEntity<?> generate(@PathVariable Long employeeId,@RequestBody Map<String,Object> body){
        Optional<Employee> found=employees.findById(employeeId);
        if(found.isEmpty()) return ResponseEntity.badRequest().body(Map.of("message","Employee not found."));
        Employee e=found.get(); if(!e.isActive()) return ResponseEntity.badRequest().body(Map.of("message","Payroll cannot be generated for an inactive employee."));
        String period=String.valueOf(body.getOrDefault("payPeriod", LocalDate.now().toString().substring(0,7)));
        double overtime=number(body.get("overtimePay"));
        if(overtime<0) return ResponseEntity.badRequest().body(Map.of("message","Overtime pay cannot be negative."));
        double gross=e.getBasicSalary()+e.getAllowances()+overtime;
        double tax=Math.round(gross*0.05*100.0)/100.0;
        Payroll p=new Payroll(); p.setEmployeeId(e.getId()); p.setEmployeeName(e.getFullName()); p.setEmployeeCode(e.getEmployeeCode());
        p.setPayPeriod(period); p.setGeneratedOn(LocalDate.now()); p.setBasicSalary(e.getBasicSalary()); p.setAllowances(e.getAllowances());
        p.setOvertimePay(overtime); p.setGrossPay(gross); p.setDeductions(e.getDeductions()); p.setTax(tax);
        p.setNetPay(Math.max(0,gross-e.getDeductions()-tax));
        return ResponseEntity.ok(payrolls.save(p));
    }
    private double number(Object v){try{return v==null?0:Double.parseDouble(v.toString());}catch(Exception ex){return 0;}}
}
