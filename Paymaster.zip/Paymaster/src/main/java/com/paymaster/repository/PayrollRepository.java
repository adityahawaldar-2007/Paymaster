package com.paymaster.repository;
import com.paymaster.model.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PayrollRepository extends JpaRepository<Payroll, Long> {
    List<Payroll> findAllByOrderByGeneratedOnDesc();
    List<Payroll> findByEmployeeIdOrderByGeneratedOnDesc(Long employeeId);
}
